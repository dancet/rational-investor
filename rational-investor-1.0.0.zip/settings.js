// By Tom Dance <tom.dance@gmail.com>
// Twitter: @tomdance

$( document ).ready(function() {

	// hide the portfolio value
	$('span[data-bind="text: portfoliovalue()"]').replaceWith( "<span style='color: #000000; background-color: #000000'>Don't worry about it :)</span>" );
});
